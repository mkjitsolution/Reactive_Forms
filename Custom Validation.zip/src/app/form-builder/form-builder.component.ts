import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import {FirstNameValidationRule} from   './FirstNameValidator';

@Component({
  selector: 'app-form-builder',
  templateUrl: './form-builder.component.html',
  styleUrls: ['./form-builder.component.css']
})
export class FormBuilderComponent implements OnInit {
  
  nomineeForm;
  constructor(formBuilder:FormBuilder) { 

    this.nomineeForm = formBuilder.group(
      {
        firstname : ['',[Validators.required,FirstNameValidationRule]],
        lastname : [''],
        kycSubmitted : [''],
        details : formBuilder.group(
          {
            gender : [''],
            relationship : ['']
          }
        )
      }
    );

  }


  get firstname()
  {
    return this.nomineeForm.get("firstname");
  }
  
  get lastname()
  {
    return this.nomineeForm.get("lastname");
  }
  
  get gender()
  {
    return this.nomineeForm.get("details").get("gender");
  }
  
  get relationship()
  {
    return this.nomineeForm.get("details").get("relationship");
  }
  
  get kycSubmitted()
  {
    return this.nomineeForm.get("kycSubmitted");
  }
  
  onSubmit() {
    console.log(this.nomineeForm.value);
  }

  ngOnInit() {
  }

}
