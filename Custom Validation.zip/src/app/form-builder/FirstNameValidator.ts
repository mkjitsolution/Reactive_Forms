import {AbstractControl,ValidatorFn} from '@angular/forms';

export function FirstNameValidationRule(control:AbstractControl)
{
    if(control.value == 'xyz')
    {
        return {"NoSuchName":true};
    }
    else return null;
}