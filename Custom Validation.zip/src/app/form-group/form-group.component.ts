import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormGroup } from '@angular/forms';


@Component({
  selector: 'app-form-group',
  templateUrl: './form-group.component.html',
  styleUrls: ['./form-group.component.css']
})
export class FormGroupComponent implements OnInit {
  
  policyForm = new FormGroup({
    policyName : new FormControl('',[Validators.required]),
    age : new FormControl(18,Validators.max(60)),
    panNumber : new FormControl('',[Validators.required,Validators.pattern('([A-Z]){5}([0-9]){4}([A-Z]){1}$')])
  });

  onFormSubmit()
  {
    console.log(this.policyForm.get("policyName").value);
    console.log(this.policyForm.get("age").value);
    console.log(this.policyForm.get("panNumber").value);
  }
  
  constructor() { }

  ngOnInit() {
  }

  get policyName(): any{
    return this.policyForm.get('policyName');
  }
  get age(): any{
    return this.policyForm.get('age');
  }
  get panNumber(): any{
    return this.policyForm.get('panNumber');
  }
  


}//end class
