import { Component, OnInit } from '@angular/core';
import { FormControl , Validator, Validators} from '@angular/forms';

@Component({
  selector: 'app-simple-reactive-form',
  templateUrl: './simple-reactive-form.component.html',
  styleUrls: ['./simple-reactive-form.component.css']
})
export class SimpleReactiveFormComponent implements OnInit {

  policyName = new FormControl('',[Validators.required]); 

  constructor() { }

  ngOnInit() {
    console.log(" ----->>>"+this.policyName.value);
  }

  getPolicyType(policyTypeControl)
  {
    let policyType:string = policyTypeControl.value;
    console.log(" --->> policy Type "+policyType);
    let nameofPolicy = "";
    if(policyType.localeCompare("Term Plan") == 0) nameofPolicy = "SBI Term Plan";
    if(policyType.localeCompare("Whole Life Insurance") == 0) nameofPolicy = "LIC-Policy";
    if(policyType.localeCompare("Money Back") == 0) nameofPolicy = "HDFC-Money Back Policy";
    if(policyType.localeCompare("Child Plan") == 0) nameofPolicy = "ICICI - Child Plan Policy";
    console.log(nameofPolicy);
   
    this.policyName.setValue(nameofPolicy); // formControl has setValue()
    // this.policyName.value = nameofPolicy // leads an Error
  
  }
}
